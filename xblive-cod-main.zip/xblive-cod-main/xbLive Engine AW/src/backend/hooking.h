#pragma once

void __declspec(naked) GLPR(void) {
	__asm {
		std     r14, -0x98(sp)
		std     r15, -0x90(sp)
		std     r16, -0x88(sp)
		std     r17, -0x80(sp)
		std     r18, -0x78(sp)
		std     r19, -0x70(sp)
		std     r20, -0x68(sp)
		std     r21, -0x60(sp)
		std     r22, -0x58(sp)
		std     r23, -0x50(sp)
		std     r24, -0x48(sp)
		std     r25, -0x40(sp)
		std     r26, -0x38(sp)
		std     r27, -0x30(sp)
		std     r28, -0x28(sp)
		std     r29, -0x20(sp)
		std     r30, -0x18(sp)
		std     r31, -0x10(sp)
		stw     r12, -0x8(sp)
		blr
	}
}

class Hooking {
public:
	BYTE szHookSection[0x500];
	BYTE szHookReplaceSection[0x500];
	int iHookCount;

	void UnhookAll();

	template <typename T>
	static bool HookFunction(DWORD dwAddress, void* pHookFunction, T* pTrampoline) {
		if (dwAddress) {
			DWORD replace = (DWORD)&szHookReplaceSection[iHookCount * 0x14];
			*(DWORD*)replace = (DWORD)dwAddress;
			memcpy((void*)(replace + 4), (void*)dwAddress, 0x10);

			DWORD* startStub = (DWORD*)&szHookSection[dwHookCount * 0x20];
			dwHookCount++;

			for (int i = 0; i < 7; i++)
				startStub[i] = 0x60000000;
			startStub[7] = 0x4E800020;

			HookFunctionStart((DWORD*)dwAddress, startStub, (DWORD)pHookFunction);

			*pTrampoline = (T)startStub;
			return true;
		}

		return false;
	}

	void PatchInJump(DWORD* dwAddress, DWORD dwDestination, bool bLinked) {
		DWORD replace = (DWORD)&szHookReplaceSection[iHookCount * 0x14];
		*(DWORD*)replace = (DWORD)dwAddress;
		memcpy((void*)(replace + 4), (void*)dwAddress, 0x10);

		if (dwDestination & 0x8000)
			dwAddress[0] = 0x3D600000 + (((dwDestination >> 16) & 0xFFFF) + 1);
		else
			dwAddress[0] = 0x3D600000 + ((dwDestination >> 16) & 0xFFFF);

		dwAddress[1] = 0x396B0000 + (dwDestination & 0xFFFF);
		dwAddress[2] = 0x7D6903A6;
		dwAddress[3] = 0x4E800420 | (bLinked ? 1 : 0);
	}

	DWORD RelinkGPLR(DWORD dwSFSOffset, DWORD* dwSaveStubAddress, DWORD* dwOriginalAddress) {
		DWORD Instruction = 0, Replacing;
		PDWORD Saver = (PDWORD)GLPR;

		if (dwSFSOffset & 0x2000000) {
			dwSFSOffset = dwSFSOffset | 0xFC000000;
		}

		Replacing = dwOriginalAddress[dwSFSOffset / 4];

		for (int i = 0; i < 20; i++) {
			if (Replacing == Saver[i]) {
				DWORD NewOffset = (DWORD)&Saver[i] - (DWORD)dwSaveStubAddress;
				Instruction = 0x48000001 | (NewOffset & 0x3FFFFFC);
			}
		}

		return Instruction;
	}

	void HookFunctionStart(DWORD* dwAddress, DWORD* dwSaveStub, DWORD dwDestination) {
		if ((dwSaveStub != NULL) && (dwAddress != NULL)) {
			DWORD AddressRelocation = (DWORD)(&dwAddress[4]);

			if (AddressRelocation & 0x8000) {
				dwSaveStub[0] = 0x3D600000 + (((AddressRelocation >> 16) & 0xFFFF) + 1);
			} else {
				dwSaveStub[0] = 0x3D600000 + ((AddressRelocation >> 16) & 0xFFFF);
			}

			dwSaveStub[1] = 0x396B0000 + (AddressRelocation & 0xFFFF);
			dwSaveStub[2] = 0x7D6903A6;

			for (int i = 0; i < 4; i++) {
				if ((dwAddress[i] & 0x48000003) == 0x48000001) {
					dwSaveStub[i + 3] = RelinkGPLR((dwAddress[i] & ~0x48000003), &dwSaveStub[i + 3], &dwAddress[i]);
				} else {
					dwSaveStub[i + 3] = dwAddress[i];
				}
			}

			dwSaveStub[7] = 0x4E800420;
			__dcbst(0, dwSaveStub);
			__sync();
			__isync();

			PatchInJump(dwAddress, dwDestination, FALSE);
		} else {
			LOG_PRINT(StrEnc("A function failed to hook, :("));
		}
	}
};

extern Hooking pHooking;

static BYTE DetourAsm[0x3000] = { 0 };
static DWORD DetourAsmIndex;
static RTL_CRITICAL_SECTION DetourAsmSection;

static int Int24ToInt32(int Value) {
	Value &= 0x00FFFFFF;
	if (Value & 0x800000)
		Value |= 0xFF000000;
	if (Value & 1)
		Value -= 1;
	return Value;
}

static bool IsZero(PVOID Scr, DWORD Size) {

	bool result;
	byte *bZeroData = new byte[Size];
	ZeroMemory(bZeroData, Size);

	result = !memcmp(Scr, bZeroData, Size);
	delete[] bZeroData;
	return result;
}

static void __declspec(naked) SetupCaller() {
	__asm
	{
		mr r3, r4
		mr r4, r5
		mr r5, r6
		mr r6, r7
		mr r7, r8
		mr r8, r9
		mr r9, r10
		blr
	}
}

static bool bCheckIfCMP(int ptr) {
	byte b = *(byte *)ptr;
	byte b2 = *(byte *)(ptr + 1);

	if (b == 0x40 || b == 0x41) {
		if (b2 == 0x9A || b2 == 0x82 || b2 == 0x99
			|| b2 == 0x81 || b2 == 0x98 || b2 == 0x80)
			return true;
	}
	return false;
}

template<class _ClassType>
class Detour {
private:
	BYTE OriginalAsm[0x10]; // 4 instructions
	DWORD DetourIndex;

	__int64 iArgs[8];
	double fArgs[8];

	// This function will get any 'b' or 'bl' and any 'cmp' function added to the stub that
	// it replaces and return the size of the stub in byte lengths
	virtual DWORD DetourFunctionStart(DWORD dwFunctionAddress, DWORD dwStubAddress, PVOID pDestFunc) {
		DWORD dwLength = 0;
		DWORD dwTemp;
		DWORD dwTempFuncAddr;
		BOOL bTemp;

		for (int i = 0; i < 4; i++) {
			dwTempFuncAddr = dwFunctionAddress + (i * 4);
			byte b = *(byte *)dwTempFuncAddr;
			byte b2 = *(byte *)(dwTempFuncAddr + 1);

			// b or bl
			if (b == 0x48 || b == 0x4B) {
				// get the branch to address
				dwTemp = dwTempFuncAddr + Int24ToInt32(*(DWORD *)dwTempFuncAddr);
				bTemp = (*(DWORD *)dwTempFuncAddr & 1) != 0;
				Hooking::PatchInJump((PDWORD)(dwStubAddress + dwLength), dwTemp, bTemp);
				dwLength += 0x10;

				// if it was a 'b loc_' call, we won't need to anything else to the stub
				if (!bTemp)
					goto DoHook;
			}

			// beq or bne, ble or bgt, bge or blt
			else if (bCheckIfCMP(dwTempFuncAddr)) {
				dwTemp = *(DWORD *)dwTempFuncAddr & 0xFFFF;

				// if bTemp is true the op code is 'beq'
				bTemp = b == 0x41;

				// check if the branch location is within the stub
				if (dwTemp <= 0x10 && dwTemp > 0) {
					if (dwTemp <= (0x10 - (i * 4))) {
						*(DWORD *)(dwStubAddress + dwLength) = *(DWORD *)dwTempFuncAddr;
						dwLength += 4;
					} else
						goto branch_else;
				} else {
				branch_else:
					// make a jump past the call if the cmp != what it is checking
					*(DWORD *)(dwStubAddress + dwLength) = ((0x40000000 + (*(DWORD *)dwTempFuncAddr & 0x00FF0000) + 0x14) +
						bTemp ? 0 : 0x01000000);
					dwLength += 4;
					Hooking::PatchInJump((PDWORD)(dwStubAddress + dwLength), (dwTempFuncAddr + dwTemp), FALSE);
					dwLength += 0x10;
				}
			}

			// if the function op code is null it is invalid
			else if (*(DWORD *)dwTempFuncAddr == 0)
				break;

			else {
				*(DWORD *)(dwStubAddress + dwLength) = *(DWORD *)dwTempFuncAddr;
				dwLength += 4;
			}
		}

		// make the stub call the orig function
		Hooking::PatchInJump((PDWORD)(dwStubAddress + dwLength), (dwFunctionAddress + 0x10), FALSE);
		dwLength += 0x10;

	DoHook:
		// apply the hook
		Hooking::PatchInJump((PDWORD)dwFunctionAddress, (DWORD)pDestFunc, FALSE);
		return dwLength;
	}

public:
	DWORD Addr;
	DWORD SaveStub;
	Detour() {};
	~Detour() {};

	virtual void SetupDetour(DWORD Address, PVOID Destination) {
		if (IsZero(&DetourAsmSection, sizeof(DetourAsmSection)))
			InitializeCriticalSection(&DetourAsmSection);

		EnterCriticalSection(&DetourAsmSection);

		DetourIndex = DetourAsmIndex;
		SaveStub = (DWORD)&DetourAsm[DetourIndex];

		// save the address incase we take-down the detour
		Addr = Address;
		// Copy the asm bytes before we replace it with the hook
		memcpy(OriginalAsm, (PVOID)Address, 0x10);

		// increment the index for the space we are using for the stub
		DetourAsmIndex += DetourFunctionStart(Address, SaveStub, Destination);

		LeaveCriticalSection(&DetourAsmSection);
	}

	virtual void SetupDetour(char* szModule, int Ordinal, PVOID Destination) {
		DWORD dwAddress;
		HMODULE mHandle = GetModuleHandle(szModule);

		if (mHandle == NULL)
			return;

		dwAddress = (DWORD)GetProcAddress(mHandle, (LPCSTR)Ordinal);

		if (dwAddress == NULL)
			return;

		SetupDetour(dwAddress, Destination);
	}

	virtual void TakeDownDetour() {
		if (Addr && MmIsAddressValid((PVOID)Addr))
			memcpy((PVOID)Addr, OriginalAsm, 0x10);
	}

	virtual _ClassType CallOriginal(...) {
		SetupCaller();
		return ((_ClassType(*)(...))SaveStub)();
	}
};