#include "stdafx.h"

Native pNative;