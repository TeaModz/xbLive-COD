#include "stdafx.h"

CodCheatInterface* pCodCheatInterface;